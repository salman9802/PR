package com.example.q10;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText playerName, playerPoints;
    Button submitBtn;

    public static final String PLAYER_NAME_KEY = "com.example.q10.MainActivity.PLAYER_NAME_KEY";
    public static final String PLAYER_POINTS_KEY = "com.example.q10.MainActivity.PLAYER_POINTS_KEY";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        playerName = (EditText) findViewById(R.id.player_name);
        playerPoints = (EditText) findViewById(R.id.player_points);
        submitBtn = (Button) findViewById(R.id.submit_btn);

        submitBtn.setOnClickListener(v -> {
            String playerName = this.playerName.getText().toString();
            String playerPoints = this.playerPoints.getText().toString();
            if(playerName.isEmpty()) Toast.makeText(this, "Player Name Empty", Toast.LENGTH_SHORT).show();
            else if(playerPoints.isEmpty()) Toast.makeText(this, "Player Points Empty", Toast.LENGTH_SHORT).show();
            else {
                Intent intent = new Intent(this, ShowPlayerDetails.class);
                intent.putExtra(PLAYER_NAME_KEY, playerName);
                intent.putExtra(PLAYER_POINTS_KEY, playerPoints);
                startActivity(intent);
            }
        });
    }
}