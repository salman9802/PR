package com.example.q10;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

public class ShowPlayerDetails extends AppCompatActivity {

    TextView playerName, playerPoints;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_player_details);

        this.playerName = (TextView) findViewById(R.id.player_name);
        this.playerPoints = (TextView) findViewById(R.id.player_points);

        Intent intent = getIntent();
        String playerName = intent.getStringExtra(MainActivity.PLAYER_NAME_KEY);
        String playerPoints = intent.getStringExtra(MainActivity.PLAYER_POINTS_KEY);

        this.playerName.setText("Player Name: " + playerName);
        this.playerPoints.setText("Player Points: " + playerPoints);

    }
}