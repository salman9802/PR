package com.example.q14;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText etNumber;
    TextView tvResult;
    Button btnCheckPalindrome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.etNumber = (EditText) findViewById(R.id.et_number);
        this.tvResult = (TextView) findViewById(R.id.tv_result);
        this.btnCheckPalindrome = (Button) findViewById(R.id.btn_check_plaindrome);

        this.btnCheckPalindrome.setOnClickListener(v -> {
            String number = this.etNumber.getText().toString();
            if(number.isEmpty()) Toast.makeText(this, "Number is Empty!", Toast.LENGTH_SHORT).show();
            else {
                if(this.isPalindrome(number)) tvResult.setText(number + " is plaindrome");
                else tvResult.setText(number + " is not a plaindrome");
            }
        });

    }

    public boolean isPalindrome(String n) {
        return n.equals(new StringBuffer(n).reverse().toString());
    }
}