package com.example.q21;

public class SMS {
    private String no = null, name = null, body = null;

    public String getNo() {
        return no;
    }

    public String getName() {
        return name;
    }

    public String getBody() {
        return body;
    }

    public void setNo(String no) {
        this.no = no;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setBody(String body) {
        this.body = body;
    }
}
