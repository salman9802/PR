package com.example.q12;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    TextView tvResult;
    EditText etN1, etN2;
    Button btnSubmit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.tvResult = (TextView) findViewById(R.id.tv_result);
        this.etN1 = (EditText) findViewById(R.id.et_n1);
        this.etN2 = (EditText) findViewById(R.id.et_n2);
        this.btnSubmit = (Button) findViewById(R.id.btn_submit);

        this.btnSubmit.setOnClickListener(v -> {
            String n1 = etN1.getText().toString();
            String n2 = etN2.getText().toString();

            if(n1.isEmpty() || n2.isEmpty()) Toast.makeText(this, "Number cannot be empty!", Toast.LENGTH_SHORT).show();
            else {
                if((Integer.parseInt(n1) > 10) && (Integer.parseInt(n2) > 10)) {
                    Toast.makeText(this, "Both numbers cannot be greater than 10!", Toast.LENGTH_SHORT).show();
                    this.etN1.setText("");
                    this.etN2.setText("");
                    this.tvResult.setText("Numbers Rejected. Both numbers should be less than 10");
                } else {
                    this.tvResult.setText("Numbers Accepted. Number 1: " + n1 + ", Number 2: " + n2);
                    this.etN1.setText("");
                    this.etN2.setText("");
                }
            }
        });
    }
}